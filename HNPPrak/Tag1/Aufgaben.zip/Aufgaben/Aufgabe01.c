#include <stdio.h>

int main(){
	printf(
		"Wilkommen zum Programmierpraktikum in C!\nIch habe gelern und mich gut vorbereitet.\nIch schaffe alle Aufgaben.\n"
			);

	return 0;
}
