int calc(int x, int y, int interval, int divisor);
