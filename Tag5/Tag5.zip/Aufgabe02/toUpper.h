int compare_ignorecase(char *string1, char *string2);
void to_upper(char *klartext);
