Nutzen Sie die Dateien dungeon.c und dungeon.h als Grundlage für Ihr Programm und beachten Sie die
Kommentare in diesen Dateien. Die Funktionen, die Sie dort finden, waren für unsere
Lösung nützlich. Sie müssen diese aber nicht verwenden!

Es gibt folgende Beispieldateien:
	spielstand.bsp
	beispielablauf.txt

Sie finden den Startspielstand in der Datei spielstand.neustart. Diese wird bei
einem Neustart immer zunächst in die Datei spielstand kopiert und darf nicht
verändert werden!

Das Makefile finden Sie in der Datei Makefile. Die Dateien loesung.sh und valgrind.sh werden vom 
Makefile benutzt. Sie müssen diese nicht weiter beachten. Alle Dateien, die mit .valgrind enden,
werden vom valgrind Test genutzt und dürfen nicht verändert werden.

Folgende Dateien sind Beschreibungen von Räumen:
	Rundgang
	Hof
	Zellentrakt
	Duschen
	Abstellkammer
	Zelle
	Kueche
	Abflussrohr
	Mensa

